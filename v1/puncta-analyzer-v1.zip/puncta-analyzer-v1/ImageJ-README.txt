28 August 2002

Running ImageJ
--------------
This is a standalone version of ImageJ 1.28 that
includes the Java Runtime Environment 1.3.1 (JRE) from Sun.

To start ImageJ, double-click on the "ImageJ" shortcut. This
is a .lnk shortcut that assumes the ImageJ folder is at
C:\ImageJ. "ImageJ (old shortcut)" is a .pif shortcut that
does not require the ImageJ folder to be at C:\Image, but it
opens a DOS window under Windows NT/2000.

To increase the amount of memory available to ImageJ, edit
the -mx option in the "Cmd Line:" field of the of either of the 
ImageJ shortcut's "Program" properties. The default is 80MB.
To avoid virtual memory "thrashing" set the -mx option to
no more than 2/3 real RAM.

Recompiling ImageJ
------------------
To recompile and run ImageJ (assumes JDK 1.3
is installed in C:\jdk1.3\):

    set PATH=C:\jdk1.3\bin;%PATH%
    set CLASSPATH=.;C:\jdk1.3\lib\tools.jar

    javac ij\ImageJ.java
    javac ij\plugin\*.java
    javac ij\plugin\filter\*.java
    javac ij\plugin\frame\*.java
    java ij.ImageJ

Any "deprecated" warning messages can be ignored. 

Files in this folder
--------------------
    ImageJ - a .lnk shortcut for running ImageJ (assumes
        the ImageJ folder is at C:\Image; edit Properties
	to use another folder)
    ImageJ (old shortcut) - a .pif shortcut for running ImageJ
    ij.jar - ImageJ binary code (class files). A JAR
        file is a ZIP file with a different extension
    jre - Sun's Java Runtime Environment 1.3.1
    plugins - user-written plugins
    ij-icon.ico - the ImageJ icon

email: wayne@codon.nih.gov
www: http://rsb.info.nih.gov/ij/